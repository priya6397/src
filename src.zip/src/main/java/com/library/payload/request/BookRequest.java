package com.library.payload.request;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class BookRequest {
    @NotEmpty(message = "Title is required")
//    @Size(max = 20, message = "Title must be at most 20 characters")
//    @Pattern(regexp = "^[a-zA-Z ]*$", message = "Title should not contain digits or special characters")
    private String title;

    private String authorName;
    private String publisherName;
    private String publisherNo;
    private String publisherEmail;
    private String bookType;
    private BigDecimal price;
    private int quantity;
    private Long libraryId;
}
